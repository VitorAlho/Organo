
import { Worker } from '../Worker'
import './Team.css'

export const Team = (props) => {

    console.log(props.coworkers.lenght)
    const members = () => {
        if(props.coworkers.lenght){
            return (
                <section className='team' style={css}>
                    <h3 style={{borderColor:props.primaryColor}}>{props.name}</h3>
                    <div className='coworkers'>
                        {props.coworkers.map(coworkers => <Worker key={coworkers.name} name={coworkers.name} imagePath={coworkers.image} work={coworkers.work}/>)}
                    </div>
                </section>
            )
        }
    }

    const css = {backgroundColor: props.secondaryColor}
    return (
        {members}
    )
}
